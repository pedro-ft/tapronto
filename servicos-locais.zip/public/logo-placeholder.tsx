export default function LogoPlaceholder() {
  return (
    <div className="flex items-center justify-center w-full h-full">
      <span className="text-white text-lg font-bold">Tá Pronto</span>
    </div>
  )
}
